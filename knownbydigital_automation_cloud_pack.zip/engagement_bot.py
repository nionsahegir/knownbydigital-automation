import time
import sys
import random
import json
import requests
from pathlib import Path

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from config import (
    META_PAGE_ACCESS_TOKEN,
    INSTAGRAM_ACCOUNT_ID,
    FACEBOOK_PAGE_ID,
    THREADS_USER_ID,
    THREADS_ACCESS_TOKEN,
    COMMENT_CHECK_INTERVAL_MINUTES,
    BRAND
)
from content_engine import call_gemini

BASE_DIR = Path(__file__).resolve().parent
REPLIED_COMMENTS_FILE = BASE_DIR / "replied_comments.json"

GRAPH_VERSION = "v21.0"
GRAPH_URL = f"https://graph.facebook.com/{GRAPH_VERSION}"
THREADS_URL = "https://graph.threads.net/v1.0"

class EngagementBot:
    def __init__(self):
        self.page_token = META_PAGE_ACCESS_TOKEN
        self.ig_account_id = INSTAGRAM_ACCOUNT_ID
        self.fb_page_id = FACEBOOK_PAGE_ID
        self.threads_user_id = THREADS_USER_ID
        self.threads_token = THREADS_ACCESS_TOKEN
        self.interval_minutes = COMMENT_CHECK_INTERVAL_MINUTES
        self.replied_comment_ids = self._load_replied_ids()

    def _load_replied_ids(self) -> set:
        if REPLIED_COMMENTS_FILE.exists():
            try:
                with open(REPLIED_COMMENTS_FILE, "r", encoding="utf-8") as f:
                    return set(json.load(f))
            except Exception:
                return set()
        return set()

    def _save_replied_ids(self):
        try:
            with open(REPLIED_COMMENTS_FILE, "w", encoding="utf-8") as f:
                json.dump(list(self.replied_comment_ids), f, indent=2)
        except Exception as e:
            print(f"[Engagement Bot Warning] Could not save replied IDs: {e}")

    def is_configured(self) -> bool:
        return bool(self.page_token and self.fb_page_id)

    def generate_smart_reply(self, comment_text: str, user_name: str = "there", platform: str = "Instagram") -> str:
        """Uses Gemini to generate an authoritative, polite, human B2B agency reply."""
        prompt = f"""
Generate an authoritative, concise {platform} comment reply from '{BRAND['name']}' to this user comment:
User: "{user_name}"
Comment: "{comment_text}"

Guidelines:
1. Native Western B2B digital agency tone: friendly, confident, high authority, concise.
2. If they mentioned a trigger word like 'SCALE', 'AUDIT', 'SYSTEM', or asked about pricing/services, acknowledge that we sent them the breakdown in their DMs.
3. Keep it under 2 sentences. Use at most 1 tasteful emoji (e.g., 🚀 or 🤝).

Return ONLY the reply text string, nothing else.
"""
        try:
            return call_gemini(prompt, response_mime_type="text/plain").strip().strip('"')
        except Exception:
            return f"Thanks for tuning in @{user_name}! Just sent the details over to your DMs 🚀"

    def _reply_to_instagram(self) -> int:
        """Polls recent Instagram media for unreplied comments."""
        if not (self.page_token and self.ig_account_id):
            return 0

        replies = 0
        try:
            media_url = f"{GRAPH_URL}/{self.ig_account_id}/media?fields=id,caption&limit=5&access_token={self.page_token}"
            media_resp = requests.get(media_url, timeout=30).json()
            media_list = media_resp.get("data", [])
        except Exception as e:
            print(f"[Engagement Bot IG Error] Could not fetch media: {e}")
            return 0

        for media in media_list:
            media_id = media["id"]
            comments_url = f"{GRAPH_URL}/{media_id}/comments?fields=id,text,username,timestamp&limit=10&access_token={self.page_token}"
            try:
                comments_resp = requests.get(comments_url, timeout=30).json()
                comments = comments_resp.get("data", [])
            except Exception:
                continue

            for comment in comments:
                cid = comment["id"]
                if cid in self.replied_comment_ids:
                    continue

                text = comment.get("text", "")
                author = comment.get("username", "friend")
                reply_text = self.generate_smart_reply(text, author, platform="Instagram")

                # Anti-ban human delay
                delay = random.randint(10, 20)
                time.sleep(delay)

                try:
                    reply_endpoint = f"{GRAPH_URL}/{cid}/replies"
                    post_res = requests.post(
                        reply_endpoint,
                        data={"message": reply_text, "access_token": self.page_token},
                        timeout=30
                    ).json()
                    if "id" in post_res:
                        print(f"[Engagement Bot - IG] Replied to @{author}: '{reply_text}'")
                        self.replied_comment_ids.add(cid)
                        self._save_replied_ids()
                        replies += 1
                except Exception as e:
                    print(f"[Engagement Bot - IG Error] Reply failed for {cid}: {e}")

                if replies >= 10:
                    break
        return replies

    def _reply_to_facebook(self) -> int:
        """Polls recent Facebook Page posts for unreplied comments."""
        if not (self.page_token and self.fb_page_id):
            return 0

        replies = 0
        try:
            feed_url = f"{GRAPH_URL}/{self.fb_page_id}/feed?fields=id,message&limit=5&access_token={self.page_token}"
            feed_resp = requests.get(feed_url, timeout=30).json()
            posts = feed_resp.get("data", [])
        except Exception as e:
            print(f"[Engagement Bot FB Error] Could not fetch feed: {e}")
            return 0

        for post in posts:
            post_id = post["id"]
            comments_url = f"{GRAPH_URL}/{post_id}/comments?fields=id,message,from&limit=10&access_token={self.page_token}"
            try:
                comments_resp = requests.get(comments_url, timeout=30).json()
                comments = comments_resp.get("data", [])
            except Exception:
                continue

            for comment in comments:
                cid = comment["id"]
                if cid in self.replied_comment_ids:
                    continue

                text = comment.get("message", "")
                author = comment.get("from", {}).get("name", "there")
                reply_text = self.generate_smart_reply(text, author, platform="Facebook")

                delay = random.randint(10, 20)
                time.sleep(delay)

                try:
                    reply_endpoint = f"{GRAPH_URL}/{cid}/comments"
                    post_res = requests.post(
                        reply_endpoint,
                        data={"message": reply_text, "access_token": self.page_token},
                        timeout=30
                    ).json()
                    if "id" in post_res:
                        print(f"[Engagement Bot - FB] Replied to {author}: '{reply_text}'")
                        self.replied_comment_ids.add(cid)
                        self._save_replied_ids()
                        replies += 1
                except Exception as e:
                    print(f"[Engagement Bot - FB Error] Reply failed for {cid}: {e}")

                if replies >= 10:
                    break
        return replies

    def _reply_to_threads(self) -> int:
        """Polls recent Threads posts for unreplied comments/replies."""
        if not (self.threads_token and self.threads_user_id):
            return 0

        replies = 0
        try:
            threads_url = f"{THREADS_URL}/{self.threads_user_id}/threads?fields=id,text&limit=5&access_token={self.threads_token}"
            threads_resp = requests.get(threads_url, timeout=30).json()
            thread_list = threads_resp.get("data", [])
        except Exception as e:
            print(f"[Engagement Bot Threads Error] Could not fetch threads: {e}")
            return 0

        for item in thread_list:
            thread_id = item["id"]
            conv_url = f"{THREADS_URL}/{thread_id}/conversation?fields=id,text,username,timestamp&limit=10&access_token={self.threads_token}"
            try:
                conv_resp = requests.get(conv_url, timeout=30).json()
                replies_data = conv_resp.get("data", [])
            except Exception:
                continue

            for reply_item in replies_data:
                rid = reply_item["id"]
                if rid in self.replied_comment_ids:
                    continue
                author = reply_item.get("username", "")
                if author == "knownbydigital":  # don't reply to our own comments
                    continue

                text = reply_item.get("text", "")
                reply_text = self.generate_smart_reply(text, author, platform="Threads")

                delay = random.randint(10, 20)
                time.sleep(delay)

                try:
                    c_url = f"{THREADS_URL}/{self.threads_user_id}/threads"
                    c_payload = {
                        "media_type": "TEXT",
                        "text": reply_text,
                        "reply_to_id": rid,
                        "access_token": self.threads_token
                    }
                    c_res = requests.post(c_url, data=c_payload, timeout=30).json()
                    creation_id = c_res.get("id")
                    if creation_id:
                        time.sleep(3)
                        pub_url = f"{THREADS_URL}/{self.threads_user_id}/threads_publish"
                        p_res = requests.post(pub_url, data={"creation_id": creation_id, "access_token": self.threads_token}, timeout=30).json()
                        if "id" in p_res:
                            print(f"[Engagement Bot - Threads] Replied to @{author}: '{reply_text}'")
                            self.replied_comment_ids.add(rid)
                            self._save_replied_ids()
                            replies += 1
                except Exception as e:
                    print(f"[Engagement Bot - Threads Error] Reply failed for {rid}: {e}")

                if replies >= 10:
                    break
        return replies

    def check_and_reply_comments(self) -> int:
        """Runs the 20-minute engagement cycle across Instagram, Facebook Page, and Threads."""
        if not self.is_configured():
            print(f"[Engagement Bot - Simulation] Checked for new comments across channels.")
            return 0

        ig_count = self._reply_to_instagram()
        fb_count = self._reply_to_facebook()
        thr_count = self._reply_to_threads()

        total = ig_count + fb_count + thr_count
        return total

if __name__ == "__main__":
    bot = EngagementBot()
    print("Testing Smart Reply Generation across channels:")
    print("Test Reply (IG):", bot.generate_smart_reply("How do I automate my Shopify store?", "alex_shopify", platform="Instagram"))
    print("Checking active comments...")
    count = bot.check_and_reply_comments()
    print(f"Engagement check complete. Replied to {count} comments.")
