import os
import sys
import time
import json
import requests
from pathlib import Path
from config import (
    META_PAGE_ACCESS_TOKEN,
    FACEBOOK_PAGE_ID,
    INSTAGRAM_ACCOUNT_ID,
    THREADS_USER_ID,
    THREADS_ACCESS_TOKEN,
    THREADS_APP_ID,
    THREADS_APP_SECRET
)
from content_engine import assemble_seo_caption


if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

GRAPH_API_VERSION = "v21.0"
GRAPH_URL = f"https://graph.facebook.com/{GRAPH_API_VERSION}"
THREADS_URL = "https://graph.threads.net/v1.0"

def upload_media_to_public_url(local_path: str) -> str:
    """
    Instagram Graph API requires public HTTPS URLs for media ingestion.
    Uploads local image/video to public storage with zero retention issues.
    """
    if str(local_path).startswith("http://") or str(local_path).startswith("https://"):
        return local_path

    path_obj = Path(local_path)
    if not path_obj.exists():
        raise FileNotFoundError(f"Media file not found: {local_path}")

    # 1. Try Catbox.moe
    try:
        with open(path_obj, "rb") as f:
            resp = requests.post(
                "https://catbox.moe/user/api.php",
                data={"reqtype": "fileupload"},
                files={"fileToUpload": (path_obj.name, f)},
                timeout=60
            )
            if resp.status_code == 200 and resp.text.startswith("https://"):
                url = resp.text.strip()
                print(f"[Public Upload] Uploaded {path_obj.name} -> {url}")
                return url
    except Exception as e:
        print(f"[Upload Warning] Catbox upload error: {e}")

    # 2. Fallback: tmpfiles.org
    try:
        with open(path_obj, "rb") as f:
            resp = requests.post(
                "https://tmpfiles.org/api/v1/upload",
                files={"file": (path_obj.name, f)},
                timeout=60
            )
            if resp.status_code == 200:
                data = resp.json()
                orig_url = data.get("data", {}).get("url", "")
                if orig_url:
                    # Convert to direct download link: tmpfiles.org/123/name -> tmpfiles.org/dl/123/name
                    dl_url = orig_url.replace("tmpfiles.org/", "tmpfiles.org/dl/")
                    print(f"[Public Upload] Fallback uploaded {path_obj.name} -> {dl_url}")
                    return dl_url
    except Exception as e:
        print(f"[Upload Warning] tmpfiles fallback error: {e}")

    raise RuntimeError(f"Could not upload {local_path} to public storage for Instagram API.")

class MetaPublisher:
    def __init__(self):
        self.page_token = META_PAGE_ACCESS_TOKEN
        self.page_id = FACEBOOK_PAGE_ID
        self.ig_user_id = INSTAGRAM_ACCOUNT_ID
        self.threads_user_id = THREADS_USER_ID
        self.threads_token = THREADS_ACCESS_TOKEN

    def is_configured(self) -> bool:
        """Returns True if Meta tokens are present."""
        return bool(self.page_token and self.page_id and self.ig_user_id)

    # ---------------------------------------------
    # 1. FACEBOOK PAGE PUBLISHING
    # ---------------------------------------------
    def publish_facebook_post(self, message: str, image_path: str = None) -> dict:
        """Publishes text or photo post to Facebook Page."""
        if not self.is_configured():
            print(f"[Simulation Mode - FB] Post simulated: '{message[:60]}...'")
            return {"status": "simulated", "platform": "facebook"}

        url = f"{GRAPH_URL}/{self.page_id}/feed"
        if image_path and os.path.exists(image_path):
            url = f"{GRAPH_URL}/{self.page_id}/photos"
            with open(image_path, "rb") as img_file:
                payload = {"caption": message, "access_token": self.page_token}
                files = {"source": img_file}
                resp = requests.post(url, data=payload, files=files, timeout=45)
                return resp.json()
        else:
            payload = {"message": message, "access_token": self.page_token}
            resp = requests.post(url, data=payload, timeout=30)
            return resp.json()

    def publish_facebook_video(self, video_path_or_url: str, description: str, title: str = None) -> dict:
        """Publishes video or Reel to Facebook Page."""
        if not self.is_configured():
            return {"status": "simulated", "platform": "facebook_video"}

        video_url = upload_media_to_public_url(video_path_or_url)
        url = f"{GRAPH_URL}/{self.page_id}/videos"
        payload = {
            "file_url": video_url,
            "description": description,
            "access_token": self.page_token
        }
        if title:
            payload["title"] = title
        try:
            resp = requests.post(url, data=payload, timeout=60).json()
            if "id" in resp:
                print(f"[Facebook Video Published] Post ID: {resp.get('id')}")
            else:
                print(f"[Facebook Video Note] {resp.get('error', {}).get('message', resp)}")
            return resp
        except Exception as e:
            print(f"[Facebook Video Error] {e}")
            return {"error": str(e)}


    # ---------------------------------------------
    # 2. INSTAGRAM PUBLISHING (Single, Carousel, Reel)
    # ---------------------------------------------
    def publish_instagram_photo(self, image_path_or_url: str, caption: str) -> dict:
        """Publishes a single photo post to Instagram Business Account."""
        if not self.is_configured():
            print(f"[Simulation Mode - IG Photo] Simulated: '{caption[:60]}...'")
            return {"status": "simulated", "platform": "instagram_photo"}

        # Get public URL
        image_url = upload_media_to_public_url(image_path_or_url)

        # Step 1: Create Container
        container_url = f"{GRAPH_URL}/{self.ig_user_id}/media"
        c_payload = {
            "image_url": image_url,
            "caption": caption,
            "access_token": self.page_token
        }
        c_res = requests.post(container_url, data=c_payload, timeout=30).json()
        creation_id = c_res.get("id")

        if not creation_id:
            return {"error": "Failed to create IG photo container", "details": c_res}

        # Step 2: Ensure Container is ready before publishing
        status_url = f"{GRAPH_URL}/{creation_id}?fields=status_code,status&access_token={self.page_token}"
        for _ in range(8):
            s_res = requests.get(status_url, timeout=15).json()
            if s_res.get("status_code") == "FINISHED":
                break
            time.sleep(2)

        # Step 3: Publish Container
        pub_url = f"{GRAPH_URL}/{self.ig_user_id}/media_publish"
        p_res = requests.post(pub_url, data={"creation_id": creation_id, "access_token": self.page_token}, timeout=30).json()
        
        # Step 3: Fetch Permalink
        media_id = p_res.get("id")
        if media_id:
            info = requests.get(f"{GRAPH_URL}/{media_id}?fields=permalink&access_token={self.page_token}", timeout=15).json()
            p_res["permalink"] = info.get("permalink")
            print(f"[Instagram Photo Published] Live URL: {p_res['permalink']}")

        return p_res

    def publish_instagram_carousel(self, image_paths_or_urls: list, caption: str) -> dict:
        """Publishes a multi-slide carousel post to Instagram."""
        if not self.is_configured():
            print(f"[Simulation Mode - IG Carousel] Simulated {len(image_paths_or_urls)} slides: '{caption[:60]}...'")
            return {"status": "simulated", "platform": "instagram_carousel", "slides": len(image_paths_or_urls)}

        # Upload slides if local
        image_urls = [upload_media_to_public_url(p) for p in image_paths_or_urls]

        # Step 1: Create child item containers
        children = []
        for img_url in image_urls:
            c_url = f"{GRAPH_URL}/{self.ig_user_id}/media"
            res = requests.post(c_url, data={"image_url": img_url, "is_carousel_item": True, "access_token": self.page_token}, timeout=30).json()
            if "id" in res:
                children.append(res["id"])
            else:
                print(f"[Carousel Child Error] Failed for {img_url}: {res}")

        if not children:
            return {"error": "Failed to create carousel items"}

        # Step 2: Create parent carousel container
        parent_url = f"{GRAPH_URL}/{self.ig_user_id}/media"
        parent_res = requests.post(parent_url, data={
            "media_type": "CAROUSEL",
            "children": ",".join(children),
            "caption": caption,
            "access_token": self.page_token
        }, timeout=30).json()

        creation_id = parent_res.get("id")
        if not creation_id:
            return {"error": "Failed to create parent carousel", "details": parent_res}

        # Step 3: Publish Carousel (brief 3s wait for Meta container propagation)
        time.sleep(3)
        pub_url = f"{GRAPH_URL}/{self.ig_user_id}/media_publish"
        p_res = requests.post(pub_url, data={"creation_id": creation_id, "access_token": self.page_token}, timeout=30).json()

        media_id = p_res.get("id")
        if media_id:
            time.sleep(2)
            info = requests.get(f"{GRAPH_URL}/{media_id}?fields=permalink&access_token={self.page_token}", timeout=15).json()
            p_res["permalink"] = info.get("permalink")
            print(f"[Instagram Carousel Published] Live URL: {p_res['permalink']}")

        return p_res

    def publish_instagram_reel(self, video_path_or_url: str, caption: str, cover_path_or_url: str = None) -> dict:
        """Publishes a vertical video as an Instagram Reel with optional custom cover thumbnail."""
        if not self.is_configured():
            print(f"[Simulation Mode - IG Reel] Simulated: '{caption[:60]}...'")
            return {"status": "simulated", "platform": "instagram_reel"}

        # Upload video to public URL
        video_url = upload_media_to_public_url(video_path_or_url)
        print(f"[Instagram Reel] Video public URL ready: {video_url}")

        # Step 1: Create REELS container
        container_url = f"{GRAPH_URL}/{self.ig_user_id}/media"
        c_payload = {
            "media_type": "REELS",
            "video_url": video_url,
            "caption": caption,
            "share_to_feed": True,
            "access_token": self.page_token
        }
        if cover_path_or_url:
            cover_url = upload_media_to_public_url(cover_path_or_url)
            print(f"[Instagram Reel] Cover thumbnail public URL ready: {cover_url}")
            c_payload["cover_url"] = cover_url

        c_res = requests.post(container_url, data=c_payload, timeout=30).json()
        creation_id = c_res.get("id")

        if not creation_id:
            return {"error": "Failed to create IG Reel container", "details": c_res}

        print(f"[Instagram Reel] Container {creation_id} created. Awaiting Meta video encoding...")

        # Step 2: Poll container status until FINISHED
        status_url = f"{GRAPH_URL}/{creation_id}?fields=status_code,status&access_token={self.page_token}"
        max_attempts = 24  # 24 * 5s = 2 minutes max
        for attempt in range(max_attempts):
            time.sleep(5)
            s_res = requests.get(status_url, timeout=20).json()
            code = s_res.get("status_code", "")
            print(f"[Instagram Reel Status] Check {attempt+1}/{max_attempts}: {code}")
            
            if code == "FINISHED":
                break
            elif code == "ERROR":
                return {"error": "Instagram Reel encoding failed on Meta servers", "details": s_res}
        else:
            return {"error": "Instagram Reel processing timed out on Meta servers"}

        # Step 3: Publish Reel Container
        pub_url = f"{GRAPH_URL}/{self.ig_user_id}/media_publish"
        p_res = requests.post(pub_url, data={"creation_id": creation_id, "access_token": self.page_token}, timeout=30).json()

        media_id = p_res.get("id")
        if media_id:
            info = requests.get(f"{GRAPH_URL}/{media_id}?fields=permalink&access_token={self.page_token}", timeout=15).json()
            p_res["permalink"] = info.get("permalink")
            print(f"[Instagram Reel Published] Live URL: {p_res['permalink']}")

        return p_res

    def publish_instagram_story(self, media_path_or_url: str) -> dict:
        """Publishes an Instagram Story (1080x1920 vertical image or video)."""
        if not self.is_configured():
            print(f"[Simulation Mode - IG Story] Simulated: {media_path_or_url}")
            return {"status": "simulated", "platform": "instagram_story"}

        media_url = upload_media_to_public_url(media_path_or_url)
        print(f"[Instagram Story] Media public URL ready: {media_url}")

        is_video = str(media_path_or_url).lower().endswith((".mp4", ".mov", ".webm"))
        container_url = f"{GRAPH_URL}/{self.ig_user_id}/media"
        payload = {
            "media_type": "STORIES",
            "access_token": self.page_token
        }
        if is_video:
            payload["video_url"] = media_url
        else:
            payload["image_url"] = media_url

        c_res = requests.post(container_url, data=payload, timeout=30).json()
        creation_id = c_res.get("id")
        if not creation_id:
            return {"error": "Failed to create Instagram Story container", "details": c_res}

        if is_video:
            status_url = f"{GRAPH_URL}/{creation_id}?fields=status_code&access_token={self.page_token}"
            for _ in range(24):
                time.sleep(5)
                s_res = requests.get(status_url, timeout=20).json()
                if s_res.get("status_code") == "FINISHED":
                    break
                elif s_res.get("status_code") == "ERROR":
                    return {"error": "Story video encoding failed", "details": s_res}

        pub_url = f"{GRAPH_URL}/{self.ig_user_id}/media_publish"
        p_res = requests.post(pub_url, data={"creation_id": creation_id, "access_token": self.page_token}, timeout=30).json()
        media_id = p_res.get("id")
        if media_id:
            p_res["status"] = "published"
            p_res["story_id"] = media_id
            print(f"[Instagram Story Published] Story Media ID: {media_id}")
        return p_res

    # ---------------------------------------------
    # 3. THREADS PUBLISHING
    # ---------------------------------------------
    def refresh_threads_token(self) -> dict:
        """Refreshes the long-lived Threads access token for another 60 days."""
        if not self.threads_token:
            return {"error": "No Threads access token found"}
        try:
            r = requests.get("https://graph.threads.net/refresh_access_token", params={
                "grant_type": "th_refresh_token",
                "access_token": self.threads_token
            }, timeout=30)
            if r.status_code == 200:
                data = r.json()
                new_token = data.get("access_token")
                if new_token:
                    self.threads_token = new_token
                    print(f"[Threads Token Refreshed] Valid for {data.get('expires_in', 0)} seconds (~60 days).")
                return data
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    def publish_threads_post(self, text: str, image_url: str = None, video_url: str = None) -> dict:
        """Publishes text, image, or video post to Meta Threads."""
        if not (self.threads_user_id and self.threads_token):
            print(f"[Simulation Mode - Threads] Simulated: '{text[:60]}...'")
            return {"status": "simulated", "platform": "threads"}

        # Upload local files to public URL if needed
        if image_url and not (str(image_url).startswith("http://") or str(image_url).startswith("https://")):
            image_url = upload_media_to_public_url(image_url)

        if video_url and not (str(video_url).startswith("http://") or str(video_url).startswith("https://")):
            video_url = upload_media_to_public_url(video_url)

        media_type = "TEXT"
        if video_url:
            media_type = "VIDEO"
        elif image_url:
            media_type = "IMAGE"

        # Step 1: Create Threads Container
        container_url = f"{THREADS_URL}/{self.threads_user_id}/threads"
        payload = {
            "media_type": media_type,
            "text": text,
            "access_token": self.threads_token
        }
        if video_url:
            payload["video_url"] = video_url
        elif image_url:
            payload["image_url"] = image_url

        c_res = requests.post(container_url, data=payload, timeout=30).json()
        creation_id = c_res.get("id")
        if not creation_id:
            return {"error": "Failed to create Threads container", "details": c_res}

        # Step 2: Ensure Container is ready (poll for video, brief sleep for image)
        if media_type == "VIDEO":
            status_url = f"{THREADS_URL}/{creation_id}?fields=status,error_message&access_token={self.threads_token}"
            for _ in range(24):
                time.sleep(5)
                s_res = requests.get(status_url, timeout=20).json()
                if s_res.get("status") == "FINISHED":
                    break
                elif s_res.get("status") == "ERROR":
                    return {"error": "Threads video processing failed", "details": s_res}
        else:
            time.sleep(3)

        # Step 3: Publish Threads Container
        pub_url = f"{THREADS_URL}/{self.threads_user_id}/threads_publish"
        p_res = requests.post(pub_url, data={"creation_id": creation_id, "access_token": self.threads_token}, timeout=30).json()
        media_id = p_res.get("id")
        if media_id:
            try:
                time.sleep(1)
                info = requests.get(f"{THREADS_URL}/{media_id}?fields=permalink&access_token={self.threads_token}", timeout=15).json()
                p_res["permalink"] = info.get("permalink")
                print(f"[Threads Post Published] Live URL: {p_res['permalink']}")
            except Exception:
                pass
        return p_res

    # ---------------------------------------------
    # 4. SIMULTANEOUS DISPATCH
    # ---------------------------------------------
    def broadcast_daily_pack(self, pack: dict, generated_media: dict) -> dict:
        """Publishes Reel, Single Post, and Carousel across Instagram and Facebook."""
        results = {}

        single_post = pack.get("single_post", {})
        carousel = pack.get("carousel", {})
        reel = pack.get("reel", {})

        # 1. Single Post (Instagram Only during initial review phase)
        post_img = generated_media.get("single_post_image")
        if post_img:
            caption = assemble_seo_caption(single_post) if single_post else ""
            results["instagram_single_post"] = self.publish_instagram_photo(post_img, caption)
            # Facebook & Threads paused until user review approval
            results["facebook_post"] = {"status": "paused_awaiting_user_approval"}
            results["threads_post"] = {"status": "paused_awaiting_user_approval"}

        # 2. Carousel
        carousel_imgs = generated_media.get("carousel_slides", [])
        if carousel_imgs:
            caption = assemble_seo_caption(carousel) if carousel else ""
            results["instagram_carousel"] = self.publish_instagram_carousel(carousel_imgs, caption)

        # 3. Faceless Reel
        reel_video = generated_media.get("reel_video")
        reel_cover = generated_media.get("reel_cover")
        if isinstance(reel_video, (list, tuple)):
            reel_cover = reel_video[1] if len(reel_video) > 1 else reel_cover
            reel_video = reel_video[0]

        if reel_video:
            caption = assemble_seo_caption(reel) if reel else ""
            results["instagram_reel"] = self.publish_instagram_reel(reel_video, caption, cover_path_or_url=reel_cover)

        # 4. Instagram Story
        story_img = generated_media.get("story_image")
        if story_img:
            results["instagram_story"] = self.publish_instagram_story(story_img)

        return results

if __name__ == "__main__":
    pub = MetaPublisher()
    print("Meta Publisher configured:", pub.is_configured())
