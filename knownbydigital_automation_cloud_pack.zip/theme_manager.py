import json
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
THEME_STATE_FILE = BASE_DIR / "theme_state.json"

THEME_ORDER = ["dark", "orange", "light"]

THEME_DISPLAY_NAMES = {
    "dark": "Stealth Charcoal (Black BG, White & Orange Text)",
    "orange": "High-Impact Orange (Orange BG, White & Black Text)",
    "light": "Clean Editorial (White BG, Orange & Charcoal Text)"
}

def load_theme_state() -> dict:
    if THEME_STATE_FILE.exists():
        try:
            with open(THEME_STATE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"current_theme": "dark", "last_date": "", "history": []}

def save_theme_state(state: dict):
    with open(THEME_STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)

def get_today_theme(force_advance: bool = False) -> str:
    """
    Returns the theme for today.
    Rotates in strict sequence: dark -> orange -> light -> dark.
    Guarantees all 4 posts in a single day share the exact same theme.
    """
    state = load_theme_state()
    today_str = datetime.now().strftime("%Y-%m-%d")

    # If already assigned today and not forcing advance, keep today's theme
    if state.get("last_date") == today_str and not force_advance:
        return state.get("current_theme", "dark")

    last_theme = state.get("current_theme", "dark")
    try:
        curr_idx = THEME_ORDER.index(last_theme)
        next_theme = THEME_ORDER[(curr_idx + 1) % len(THEME_ORDER)]
    except ValueError:
        next_theme = "orange"

    state["current_theme"] = next_theme
    state["last_date"] = today_str
    if "history" not in state:
        state["history"] = []
    state["history"].append({
        "date": today_str,
        "theme": next_theme,
        "display": THEME_DISPLAY_NAMES.get(next_theme)
    })
    # Keep only last 30 days history
    state["history"] = state["history"][-30:]
    save_theme_state(state)
    print(f"[Theme Manager] Active Theme for {today_str}: {next_theme} ({THEME_DISPLAY_NAMES.get(next_theme)})")
    return next_theme

def set_current_theme(theme_name: str) -> str:
    """Manually override current theme."""
    if theme_name not in THEME_ORDER:
        raise ValueError(f"Invalid theme: {theme_name}. Choose from {THEME_ORDER}")
    today_str = datetime.now().strftime("%Y-%m-%d")
    state = load_theme_state()
    state["current_theme"] = theme_name
    state["last_date"] = today_str
    save_theme_state(state)
    print(f"[Theme Manager] Theme set manually to: {theme_name}")
    return theme_name

if __name__ == "__main__":
    t = get_today_theme()
    print("Today's Theme:", t)
