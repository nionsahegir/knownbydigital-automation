import os
import sys
import argparse
from datetime import datetime
from pathlib import Path

# Ensure UTF-8 output on all platforms
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)

from scheduler_daemon import (
    job_post_single_post,
    job_post_reel,
    job_post_story,
    job_post_carousel,
    job_check_comments,
    job_clean_storage,
    job_refresh_tokens
)

def run_auto_job():
    """Selects job based on current UTC hour, or runs engagement check by default."""
    utc_now = datetime.utcnow()
    current_utc_hour = utc_now.hour
    current_utc_minute = utc_now.minute
    print(f"[RunJob Auto] Current UTC time: {utc_now.strftime('%Y-%m-%d %H:%M:%S UTC')}")

    # Slot matching (UTC hours):
    # 08:00 UTC (14:00 BST) -> Single Post
    # 12:30 UTC (18:30 BST) -> Reel
    # 15:30 UTC (21:30 BST) -> Story
    # 18:30 UTC (00:30 BST) -> Carousel
    if current_utc_hour == 8:
        job_post_single_post()
    elif current_utc_hour == 12:
        job_post_reel()
    elif current_utc_hour == 15:
        job_post_story()
    elif current_utc_hour == 18:
        job_post_carousel()
    else:
        print("[RunJob Auto] No scheduled publishing slot at this exact hour. Running engagement check.")
        job_check_comments()

def main():
    parser = argparse.ArgumentParser(description="Known By Digital Scheduled Job Runner")
    parser.add_argument(
        "--job",
        choices=["single_post", "reel", "story", "carousel", "check_comments", "clean", "refresh_tokens", "auto"],
        default="auto",
        help="Specify which task to run"
    )
    args = parser.parse_args()

    print(f"🚀 Running job: '{args.job}' at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    if args.job == "single_post":
        job_post_single_post()
    elif args.job == "reel":
        job_post_reel()
    elif args.job == "story":
        job_post_story()
    elif args.job == "carousel":
        job_post_carousel()
    elif args.job == "check_comments":
        job_check_comments()
    elif args.job == "clean":
        job_clean_storage()
    elif args.job == "refresh_tokens":
        job_refresh_tokens()
    elif args.job == "auto":
        run_auto_job()

if __name__ == "__main__":
    main()
